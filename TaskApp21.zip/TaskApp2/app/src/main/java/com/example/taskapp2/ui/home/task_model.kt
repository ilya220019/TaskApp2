package com.example.taskapp2.ui.home

data class task_model(
    val title: String,
    val description: String
)
